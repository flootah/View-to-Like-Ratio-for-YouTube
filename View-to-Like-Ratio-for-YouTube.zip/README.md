# View-to Like Ratio for YouTube
 chrome extension to help judge a video's quality by adding a view-to-like ratio or percentage to the watch page.
